/*
** EPITECH PROJECT, 2020
** tree.c
** File description:
** 
*/

//Calcul pour la hauteur du tronc

int height_trunk(int size)
{
    int height = size;
    return (height);
}

//Calcul pour la largeur du tronc

int width_trunk(int size)
{
    int width = 0;
    if (size % 2 == 0){
        width = size;
        width++;
    }
    else {
        width = size;
    }
    return (width);
}

//Calcul pour la base de l'arbre avec la derniere ligne

int base_tree(int size)
{
    int i = 7;
    int plus = 6;
    int curs = 0;
    while (curs != size) {
        if (curs % 2 != 0) {
        plus = plus + 2;
        }
    i = i + plus;
    curs++;
    }
    i = i - plus;
    return (i);
}

//Calcul pour le haut de l'arbre avec la premiere ligne 

int	top_tree(int size)
{
  int	i;
  int	difference;
  int	firstline;
  firstline = 1;
  difference = 4;
  for (i = 1; i < size; i++)
    {
      if ((i % 2) != 0)
	firstline += difference;
      else if (i !=  1)
	{
	  difference += 2;
	  firstline += difference;
	}
  }
  return (firstline);
}

//dessiner le tronc

int draw_trunk(int size)
{
    int y = width_trunk(size);
    int cpy = 0;
    int i = height_trunk(size);
    int spaces =(base_tree(size) / 2) - (width_trunk(size)/ 2);
    int j;

    while (i > 0){
        i--;
        cpy = y;

        for (j = 0; j < spaces; j++)
        my_putchar(' ');

        while (cpy > 0){
            cpy--;
            my_putchar('|');
            }
        my_putchar('\n');
    }
    return 0;
}

//dessiner l'arbre avec les etoiles

void	draw(int size2, int size)
{
  int	i;
  int	j;
  int	difference;
  int	spaces;
  int	stars;
  int	height_branche;

  spaces = base_tree(size) / 2 - top_tree(size2) / 2;
  stars = top_tree(size2) - 1;
  difference = 4;
  height_branche = size2 + 3;
  for (i = 0; i < height_branche; i++)
    {
      for (j = 0; j < spaces; j++)
	my_putchar(' ');
      for (j = 0; j < stars; j++)
	my_putchar('*');
      spaces--;
      stars += 2;
      my_putchar('*');
      my_putchar('\n');
      }
}


void tree(int size)
{
      int i = 0;

  if (size > 0)
    {
      i = 1;
      while (i <= size)
	{
	  draw(i, size);
	  i++;
	}
      draw_trunk(size);
    }
}